package bank;

import java.sql.Connection;
import java.sql.DriverManager;

public class BankConncetionClass {
private static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver" ;
private static final String URL = "jdbc:mysql://localhost:3306/Bank";
private static final String US_NAME = "root";
private static final String PASS = "root";
static Connection conn = null;
public static Connection getConnection() {
	try {
		Class.forName(DB_DRIVER);
		conn = DriverManager.getConnection(URL,US_NAME , PASS);
		if(conn!=null)
		{
			System.out.println("connected ");
		}
		else {
			System.out.println("Not connected");
		}
	}catch(Exception e) {
		e.printStackTrace();
	}
	return conn;
}
}
