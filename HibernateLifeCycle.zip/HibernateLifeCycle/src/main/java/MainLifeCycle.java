import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class MainLifeCycle {

	public static void main(String[] args) {
MyLaptop lob=new MyLaptop(); //new State  Transient
		
		Configuration con=new Configuration().configure().addAnnotatedClass(MyLaptop.class);
		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		//ServiceRegistry reg1=new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		
		SessionFactory sf=con.buildSessionFactory(reg);
		Session session=sf.openSession();
		Transaction tx=session.beginTransaction();
        
		/*lob.setLid(2);
		lob.setLname("hp");
		lob.setLprice(100);  //object is in transient state
		
		session.save(lob);  //persistant state always data is there in database
		lob.setLprice(350);
		tx.commit();*/
		
		
		//detach state
		
		/*lob.setLid(112);
		lob.setLname("Dell");
		lob.setLprice(700);
		session.save(lob);
		
		tx.commit();
	  session.evict(lob);
		lob.setLprice(650);*///not updated in database
          
		//object is in detached state
		
		
	
		//remove state
		lob.setLid(116);
		lob.setLname("Samsung");
		lob.setLprice(900);
		//persistent
		session.save(lob);
		//tx.commit();
		session.delete(lob);

	}

}
