package one;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		final String DB_URl = "jdbc:Mysql://localhost:3306/edu";
		final String DB_UNM = "root";
		final String DB_PASS  = "root";
		Class.forName("com.Mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection(DB_URl, DB_UNM, DB_PASS);
		Statement st = conn.createStatement();
		String s = "create table babo(id int.name var char(20))";
		st.execute(s);
		System.out.println("created");

	}

}
